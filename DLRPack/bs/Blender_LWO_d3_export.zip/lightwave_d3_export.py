#!BPY

"""
Name: 'LightWave for Doom3 (.lwo)...'
Blender: 243
Group: 'Export'
Tooltip: 'Export selected meshes to LightWave File Format (.lwo)'
"""

__author__ = "Anthony D'Agostino (Scorpius), edited by c4tnt"
__url__ = ("blender", "blenderartists.org","")
__version__ = "Part of IOSuite 0.5"

__bpydoc__ = """\
This script exports meshes to LightWave file format.

LightWave is a full-featured commercial modeling and rendering
application. The lwo file format is composed of 'chunks,' is well
defined, and easy to read and write. It is similar in structure to the
trueSpace cob format.

Usage:<br>
	Select meshes to be exported and run this script from "File->Export" menu.

Supported:<br>
	UV Coordinates, Meshes, Materials, Material Indices, Specular
Highlights, and Vertex Colors. For added functionality, each object is
placed on its own layer. Someone added the CLIP chunk and imagename support.

Missing:<br>
	Not too much, I hope! :).

Known issues:<br>
	Empty objects crash has been fixed.

Notes:<br>
	For compatibility reasons, it also reads lwo files in the old LW
v5.5 format.
"""

# $Id: lightwave_export.py 20071 2009-05-05 21:51:54Z campbellbarton $
#
# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | April 21, 2002                                          |
# | Read and write LightWave Object File Format (*.lwo)     |
# +---------------------------------------------------------+

# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****

import Blender
import BPyMesh
import re
try: import struct
except: struct = None
try: import cStringIO
except: cStringIO = None
try: import operator
except: operator = None

VCOL_NAME = "\251 Per-Face Vertex Colors"
DEFAULT_NAME = "\251 Blender Default"
# ==============================
# === Write LightWave Format ===
# ==============================
def preload():
	scn = Blender.Scene.GetCurrent()
	objects = list(scn.objects.context)
	
	if not objects:
		Blender.Draw.PupMenu('Error%t|No Objects selected')
		return
	
	try:	objects.sort( key = lambda a: a.name )
	except:	objects.sort(lambda a,b: cmp(a.name, b.name))

	meshes = []
	mesh_object_name_lookup = {} # for name lookups only
	
	for obj in objects:
		mesh = BPyMesh.getMeshFromObject(obj, None, True, False, scn)
		if mesh:
			mesh.transform(obj.matrixWorld)
			meshes.append(mesh)
			mesh_object_name_lookup[mesh] = obj.name
	del obj
	return meshes, mesh_object_name_lookup

def write(filename, meshes, mesh_object_name_lookup, material_names, material_names_map_btn):
	start = Blender.sys.time()
	file = open(filename, "wb")
	
	material_names_map = mmap_make(material_names, material_names_map_btn)
	del material_names_map_btn

	tags = generate_tags(material_names,material_names_map)
	surfs = generate_surfs(material_names, material_names_map)
	chunks = [tags]

	meshdata = cStringIO.StringIO()
	
	layer_index = 0
	
	for mesh in meshes:
		layr = generate_layr(mesh_object_name_lookup[mesh], layer_index)
		pnts = generate_pnts(mesh)
		bbox = generate_bbox(mesh)
		pols = generate_pols(mesh)
		ptag = generate_ptag(mesh, material_names)

		if mesh.faceUV:
			vmad_uv = generate_vmad_uv(mesh)  # per face

		if mesh.vertexColors:
			vmad_vc = generate_vmad_vc(mesh)  # per face

		write_chunk(meshdata, "LAYR", layr); chunks.append(layr)
		write_chunk(meshdata, "PNTS", pnts); chunks.append(pnts)
		write_chunk(meshdata, "BBOX", bbox); chunks.append(bbox)
		write_chunk(meshdata, "POLS", pols); chunks.append(pols)
		write_chunk(meshdata, "PTAG", ptag); chunks.append(ptag)

		if mesh.vertexColors:
			write_chunk(meshdata, "VMAD", vmad_vc)
			chunks.append(vmad_vc)

		if mesh.faceUV:
			write_chunk(meshdata, "VMAD", vmad_uv)
			chunks.append(vmad_uv)
		
		layer_index += 1
		mesh.verts = None # save some ram
	
	del mesh_object_name_lookup
	
	for surf in surfs:
		chunks.append(surf)

	write_header(file, chunks)

	write_chunk(file, "TAGS", tags)
	file.write(meshdata.getvalue()); meshdata.close()
	for surf in surfs:
		write_chunk(file, "SURF", surf)

	Blender.Window.DrawProgressBar(1.0, "")    # clear progressbar
	file.close()
#	print '\a\r',
	print "Successfully exported %s in %.3f seconds" % (filename.split('\\')[-1].split('/')[-1], Blender.sys.time() - start)
	

# =======================================
# === Material Mapping Menu ===
# =======================================

def generate_menu(ev_base, ui_x, ui_y, ui_wt,ui_wb, ui_h, ui_max_h, pad_col, material_names, material_names_map, material_names_var):
	i = ev_base
	x = 0
	y = 0
	m_y = 0

	Blender.Draw.BeginAlign()
	for N in material_names:
		if (y > ui_max_h):
			y = 0
			x += ui_wt + ui_wb*3 + pad_col
			Blender.Draw.EndAlign()
			Blender.Draw.BeginAlign()

		Blender.Draw.Label(N+': ', ui_x + x, ui_y - y, ui_wt + ui_wb, ui_h)
		y += ui_h + 1
		material_names_map[N] = Blender.Draw.String("", i, ui_x + x, ui_y - y, ui_wt, ui_h, material_names_var[N], 255, "Enter Doom3 mateiral name to assign to")
		Blender.Draw.PushButton("-",i+1,ui_x+ui_wt + x,ui_y-y,ui_wb,ui_h,"Do not include this material")
		Blender.Draw.PushButton("o",i+2,ui_x+ui_wt+ui_wb + x,ui_y-y,ui_wb,ui_h,"Try to recover this material")
		Blender.Draw.PushButton("k",i+3,ui_x+ui_wt+ui_wb*2 + x,ui_y-y,ui_wb,ui_h,"Keep as is")
		i += 4
		y += ui_h + 1
		if (y > m_y): 
			m_y = y

	Blender.Draw.EndAlign()

	return i, x, m_y

def update_menu(material_names, material_names_map, material_names_var):
	for N in material_names:
		T = material_names_map[N].val
		T = T.strip().replace('\\', '/')
		J = T.replace('//', '/')

		while (T != J): 
			T = J
			J = T.replace('//', '/')

		if T[0] == '/': T = T[1:]		
		
		if T.lower() == '' or T == '<keep>':
			material_names_var[N] = '<keep>'
		elif T.lower() == '<old>':
			material_names_var[N] = '<old>'
		elif T.lower() == '<none>':
			material_names_var[N] = '<none>'
		elif re.search('<*>',T):
			material_names_var[N] = '<keep>'
		else:
			material_names_var[N] = T

def generate_menu_var(material_names):
	material_names_var = {}
	for N in material_names:
		material_names_var[N] = "<keep>"
	return material_names_var

def mmap_make(material_names, material_names_map):
	Mapped = {}
	for N in material_names:
		if material_names_map[N].val:
			if material_names_map[N].val == '<keep>':
				Mapped[N] = N
			else:
				Mapped[N] = material_names_map[N].val
		else:
			Mapped[N] = N
	return Mapped

def map_mat(material_names,material_names_map):
	return material_names_map[material_names]

def load_obj_ui(filename, meshes, mesh_object_name_lookup):
	
	EVENT_NONE = 0
	EVENT_EXIT = 1
	EVENT_REDRAW = 2
	EVENT_EXPORT = 3
	EVENT_MENUBASE = 4
		
	GLOBALS = {}
	GLOBALS['EVENT'] = EVENT_REDRAW
	GLOBALS['MOUSE'] = Blender.Window.GetMouseCoords()
	GLOBALS['CENTER'] = [i/2 for i in Blender.Window.GetScreenSize()]

	material_names = get_used_material_names(meshes)
	material_names_var = generate_menu_var(material_names)
	material_names_map = {}

	def obj_ui_set_event(e,v):
		GLOBALS['EVENT'] = e
	
	def obj_ui():
		ui_x, ui_y = GLOBALS['CENTER']
		
		# Center based on overall pup size
		ui_x -= 165
		ui_y -= 90
			
		Blender.Draw.Label('Image mapping...', ui_x+9, ui_y - 5, 220, 21)

		eoffs, menu_w, menu_h = generate_menu(EVENT_MENUBASE, ui_x+9, ui_y - 27, 175,15, 21, 200, 20, material_names, material_names_map, material_names_var)
		Blender.Draw.BeginAlign()
		Blender.Draw.PushButton('Get old', EVENT_NONE, ui_x+9, ui_y - menu_h-32 , 60, 21, '', obj_ui_set_event)
		Blender.Draw.EndAlign()

		Blender.Draw.BeginAlign()
		Blender.Draw.PushButton('Cancel', EVENT_EXIT, ui_x+10, ui_y - menu_h - 60, 110, 21, '', obj_ui_set_event)
		Blender.Draw.PushButton('Export', EVENT_EXPORT, ui_x+120, ui_y - menu_h - 60, 110, 21, 'Export with these settings', obj_ui_set_event)
		Blender.Draw.EndAlign()
			
	# hack so the toggle buttons redraw. this is not nice at all
	while GLOBALS['EVENT'] not in (EVENT_EXIT, EVENT_EXPORT):
		Blender.Draw.UIBlock(obj_ui, 0)
		update_menu(material_names, material_names_map, material_names_var)
		
	if GLOBALS['EVENT'] != EVENT_EXPORT:
		return

	Blender.Window.WaitCursor(1)
	write (filename, meshes, mesh_object_name_lookup, material_names, material_names_map);
		
# =======================================
# === Generate Null-Terminated String ===
# =======================================
def generate_nstring(string):
	if len(string)%2 == 0:	# even
		string += "\0\0"
	else:					# odd
		string += "\0"
	return string

# ===============================
# === Get Used Material Names ===
# ===============================
def get_used_material_names(meshes):
	matnames = {}
	for mesh in meshes:
		if (not mesh.materials) and mesh.vertexColors:
			# vcols only
			matnames[VCOL_NAME] = None
			
		elif mesh.materials and (not mesh.vertexColors):
			# materials only
			for material in mesh.materials:
				if material:
					matnames[material.name] = None
		elif (not mesh.materials) and (not mesh.vertexColors):
			# neither
			matnames[DEFAULT_NAME] = None
		else:
			# both
			for material in mesh.materials:
				if material:
					matnames[material.name] = None
	return matnames.keys()

# =========================================
# === Generate Tag Strings (TAGS Chunk) ===
# =========================================
def generate_tags(material_names, material_names_map):
	if material_names:
		material_names = map(lambda N: generate_nstring(material_names_map[N]), material_names)
		tags_data = reduce(operator.add, material_names)
	else:
		tags_data = generate_nstring('');
	return tags_data

# ========================
# === Generate Surface ===
# ========================
def generate_surface(name, m_material):
	#if name.find("\251 Per-") == 0:
	#	return generate_vcol_surf(mesh)
	if name == DEFAULT_NAME:
		return generate_default_surf()
	else:
		return generate_surf(name, m_material)

# ======================
# === Generate Surfs ===
# ======================
def generate_surfs(material_names, material_names_map):
	return map(lambda S: generate_surface(S, material_names_map[S]) , material_names)

# ===================================
# === Generate Layer (LAYR Chunk) ===
# ===================================
def generate_layr(name, idx):
	data = cStringIO.StringIO()
	data.write(struct.pack(">h", idx))          # layer number
	data.write(struct.pack(">h", 0))            # flags
	data.write(struct.pack(">fff", 0, 0, 0))    # pivot
	data.write(generate_nstring(name))			# name
	return data.getvalue()

# ===================================
# === Generate Verts (PNTS Chunk) ===
# ===================================
def generate_pnts(mesh):
	data = cStringIO.StringIO()
	for i, v in enumerate(mesh.verts):
		if not i%100:
			Blender.Window.DrawProgressBar(float(i)/len(mesh.verts), "Writing Verts")
		x, y, z = v.co
		data.write(struct.pack(">fff", x, z, y))
	return data.getvalue()

# ==========================================
# === Generate Bounding Box (BBOX Chunk) ===
# ==========================================
def generate_bbox(mesh):
	data = cStringIO.StringIO()
	# need to transform verts here
	if mesh.verts:
		nv = [v.co for v in mesh.verts]
		xx = [ co[0] for co in nv ]
		yy = [ co[1] for co in nv ]
		zz = [ co[2] for co in nv ]
	else:
		xx = yy = zz = [0.0,]
	
	data.write(struct.pack(">6f", min(xx), min(zz), min(yy), max(xx), max(zz), max(yy)))
	return data.getvalue()

# ====================================================
# === Generate Per-Face Vertex Colors (VMAD Chunk) ===
# ====================================================
def generate_vmad_vc(mesh):
	data = cStringIO.StringIO()
	data.write("RGB ")                                      # type
	data.write(struct.pack(">H", 3))                        # dimension
	data.write(generate_nstring("Blender's Vertex Colors")) # name
	for i, f in enumerate(mesh.faces):
		if not i%100:
			Blender.Window.DrawProgressBar(float(i)/len(mesh.faces), "Writing Vertex Colors")
		col = f.col
		f_v = f.v
		for j in xrange(len(f)-1, -1, -1): 			# Reverse order
			r,g,b, dummy = tuple(col[j])
			data.write(struct.pack(">H", f_v[j].index)) # vertex index
			data.write(struct.pack(">H", i)) # face index
			data.write(struct.pack(">fff", r/255.0, g/255.0, b/255.0))
	return data.getvalue()

# ================================================
# === Generate Per-Face UV Coords (VMAD Chunk) ===
# ================================================
def generate_vmad_uv(mesh):
	layers = mesh.getUVLayerNames()
	org_uv = mesh.activeUVLayer
	for l in layers:
		mesh.activeUVLayer = l
		data = cStringIO.StringIO()
		data.write("TXUV")                                       # type
		data.write(struct.pack(">H", 2))                         # dimension
		data.write(generate_nstring(l)) # name
		for i, f in enumerate(mesh.faces):
			if not i%100:
				Blender.Window.DrawProgressBar(float(i)/len(mesh.faces), "Writing UV Coordinates")
			
			uv = f.uv
			f_v = f.v
			for j in xrange(len(f)-1, -1, -1):             # Reverse order
				U,V = uv[j]
				v = f_v[j].index
				data.write(struct.pack(">H", v)) # vertex index
				data.write(struct.pack(">H", i)) # face index
				data.write(struct.pack(">ff", U, V))
	
	mesh.activeUVLayer = org_uv
	return data.getvalue()

# ======================================
# === Generate Variable-Length Index ===
# ======================================
def generate_vx(index):
	if index < 0xFF00:
		value = struct.pack(">H", index)                 # 2-byte index
	else:
		value = struct.pack(">L", index | 0xFF000000)    # 4-byte index
	return value

# ===================================
# === Generate Faces (POLS Chunk) ===
# ===================================
def generate_pols(mesh):
	data = cStringIO.StringIO()
	data.write("FACE")  # polygon type
	for i,f in enumerate(mesh.faces):
		if not i%100:
			Blender.Window.DrawProgressBar(float(i)/len(mesh.faces), "Writing Faces")
		data.write(struct.pack(">H", len(f))) # numfaceverts
		numfaceverts = len(f)
		f_v = f.v
		for j in xrange(numfaceverts-1, -1, -1): 			# Reverse order
			data.write(generate_vx(f_v[j].index))
	return data.getvalue()

# =================================================
# === Generate Polygon Tag Mapping (PTAG Chunk) ===
# =================================================
def generate_ptag(mesh, material_names):
	
	def surf_indicies(mat):
		try:
			if mat:
				return material_names.index(mat.name)
		except:
			pass
		
		return 0
		
	
	data = cStringIO.StringIO()
	data.write("SURF")  # polygon tag type
	mesh_materials = mesh.materials
	mesh_surfindicies = [surf_indicies(mat) for mat in mesh_materials]
	
	try:	VCOL_NAME_SURF_INDEX = material_names.index(VCOL_NAME)
	except:	VCOL_NAME_SURF_INDEX = 0
	
	try:	DEFAULT_NAME_SURF_INDEX = material_names.index(DEFAULT_NAME)
	except:	DEFAULT_NAME_SURF_INDEX = 0
	len_mat = len(mesh_materials)
	for i, f in enumerate(mesh.faces): # numfaces
		f_mat = f.mat
		if f_mat >= len_mat: f_mat = 0 # Rare annoying eror
			
		
		if not i%100:
			Blender.Window.DrawProgressBar(float(i)/len(mesh.faces), "Writing Surface Indices")
		
		data.write(generate_vx(i))
		if (not mesh_materials) and mesh.vertexColors:		# vcols only
			surfidx = VCOL_NAME_SURF_INDEX
		elif mesh_materials and not mesh.vertexColors:		# materials only
			surfidx = mesh_surfindicies[f_mat]
		elif (not mesh_materials) and (not mesh.vertexColors):	# neither
			surfidx = DEFAULT_NAME_SURF_INDEX
		else:												# both
			surfidx = mesh_surfindicies[f_mat]
		
		data.write(struct.pack(">H", surfidx)) # surface index
	return data.getvalue()

# ===================================================
# === Generate VC Surface Definition (SURF Chunk) ===
# ===================================================
def generate_vcol_surf(mesh):
	data = cStringIO.StringIO()
	if mesh.vertexColors:
		surface_name = generate_nstring(VCOL_NAME)
	data.write(surface_name)
	data.write("\0\0")

	data.write("COLR")
	data.write(struct.pack(">H", 14))
	data.write(struct.pack(">fffH", 1, 1, 1, 0))

	data.write("DIFF")
	data.write(struct.pack(">H", 6))
	data.write(struct.pack(">fH", 0.0, 0))

	data.write("LUMI")
	data.write(struct.pack(">H", 6))
	data.write(struct.pack(">fH", 1.0, 0))

	data.write("VCOL")
	data.write(struct.pack(">H", 34))
	data.write(struct.pack(">fH4s", 1.0, 0, "RGB "))  # intensity, envelope, type
	data.write(generate_nstring("Blender's Vertex Colors")) # name

	data.write("CMNT")  # material comment
	comment = "Vertex Colors: Exported from Blender\256 243"
	comment = generate_nstring(comment)
	data.write(struct.pack(">H", len(comment)))
	data.write(comment)
	return data.getvalue()

# ================================================
# === Generate Surface Definition (SURF Chunk) ===
# ================================================
def generate_surf(material_name, mapped_material_name):
	data = cStringIO.StringIO()
	data.write(generate_nstring(mapped_material_name))
	data.write("\0\0")
	
	try:
		material = Blender.Material.Get(material_name)
		R,G,B = material.R, material.G, material.B
		ref = material.ref
		emit = material.emit
		spec = material.spec
		hard = material.hard
		
	except:
		material = None
		
		R=G=B = 1.0
		ref = 1.0
		emit = 0.0
		spec = 0.2
		hard = 0.0
	
	data.write("CMNT")  # material comment
	comment = material_name + " mapped as " + mapped_material_name
	comment = generate_nstring(comment)
	data.write(struct.pack(">H", len(comment)))
	data.write(comment)
	
	data.write("BLOK")                  # Surface BLOK header

	data_tmp = cStringIO.StringIO()

	# IMAP subchunk (image map sub header)
	data_tmp.write("IMAP")                  
	data_tmp2 = cStringIO.StringIO()
	data_tmp2.write(struct.pack(">H", 0))  # Hardcoded - not sure what it represents
	data_tmp2.write("ENAB")
	data_tmp2.write(struct.pack(">HH", 2, 1))  # 1 = texture layer enabled
	data_tmp.write(struct.pack(">H", len(data_tmp2.getvalue())))
	data_tmp.write(data_tmp2.getvalue())

	# TMAP subchunk (image map sub header)
	data_tmp.write("TMAP")                  
	data_tmp2 = cStringIO.StringIO()

	data_tmp2.write("CNTR")
	data_tmp2.write(struct.pack(">H", 14))
	data_tmp2.write(struct.pack(">f", 0))	#X
	data_tmp2.write(struct.pack(">f", 0))	#Y
	data_tmp2.write(struct.pack(">f", 0))	#Z
	data_tmp2.write(struct.pack(">H", 0))	#Envelope - all disabled

	data_tmp.write(struct.pack(">H", len(data_tmp2.getvalue())))
	data_tmp.write(data_tmp2.getvalue())

	data_tmp.write("VMAP")
	uvname = generate_nstring(mapped_material_name)
	data_tmp.write(struct.pack(">H", len(uvname)))
	data_tmp.write(uvname)
	data.write(struct.pack(">H", len(data_tmp.getvalue())))
	data.write(data_tmp.getvalue())

	return data.getvalue()

# =============================================
# === Generate Default Surface (SURF Chunk) ===
# =============================================
def generate_default_surf():
	data = cStringIO.StringIO()
	material_name = DEFAULT_NAME
	data.write(generate_nstring(material_name))
	data.write("\0\0")

	data.write("COLR")
	data.write(struct.pack(">H", 14))
	data.write(struct.pack(">fffH", 1, 1, 1, 0))

	data.write("DIFF")
	data.write(struct.pack(">H", 6))
	data.write(struct.pack(">fH", 0.8, 0))

	data.write("LUMI")
	data.write(struct.pack(">H", 6))
	data.write(struct.pack(">fH", 0, 0))

	data.write("SPEC")
	data.write(struct.pack(">H", 6))
	data.write(struct.pack(">fH", 0.5, 0))

	data.write("GLOS")
	data.write(struct.pack(">H", 6))
	gloss = 50 / (255/2.0)
	gloss = round(gloss, 1)
	data.write(struct.pack(">fH", gloss, 0))

	data.write("CMNT")  # material comment
	comment = material_name + ": Exported from Blender\256 243"

	# vals = map(chr, xrange(164,255,1))
	# keys = xrange(164,255,1)
	# keys = map(lambda x: `x`, keys)
	# comment = map(None, keys, vals)
	# comment = reduce(operator.add, comment)
	# comment = reduce(operator.add, comment)

	comment = generate_nstring(comment)
	data.write(struct.pack(">H", len(comment)))
	data.write(comment)
	return data.getvalue()

# ===================
# === Write Chunk ===
# ===================
def write_chunk(file, name, data):
	file.write(name)
	file.write(struct.pack(">L", len(data)))
	file.write(data)

# =============================
# === Write LWO File Header ===
# =============================
def write_header(file, chunks):
	chunk_sizes = map(len, chunks)
	chunk_sizes = reduce(operator.add, chunk_sizes)
	form_size = chunk_sizes + len(chunks)*8 + len("FORM")
	file.write("FORM")
	file.write(struct.pack(">L", form_size))
	file.write("LWO2")

def fs_callback(filename,meshes, mesh_object_name_lookup):
	if not filename.lower().endswith('.lwo'): filename += '.lwo'
	load_obj_ui(filename,meshes, mesh_object_name_lookup)

if struct and cStringIO and operator:

	meshes, mesh_object_name_lookup = preload()

	Blender.Window.FileSelector(lambda N: fs_callback(N, meshes, mesh_object_name_lookup), "Export LWO", Blender.sys.makename(ext='.lwo'))
else:
	Blender.Draw.PupMenu("Error%t|This script requires a full python installation")
